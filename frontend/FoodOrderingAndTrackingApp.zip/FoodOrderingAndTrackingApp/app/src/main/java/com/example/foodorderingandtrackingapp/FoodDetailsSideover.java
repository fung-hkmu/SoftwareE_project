package com.example.foodorderingandtrackingapp;

public class FoodDetailsSideover {
}
